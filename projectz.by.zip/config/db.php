<?php
define('SERVER', 'localhost');
define('USER', 'root');
define('PASSWORD', 'root');
define('DB', 'php_stage2_project');