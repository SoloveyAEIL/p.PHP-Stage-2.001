<?php
// logout page template


logout();